/* script.js
   - Contains data, rendering for pages, cart logic (localStorage), and simple UI interactions.
   - Designed to be used across all HTML pages.
*/

/* ---------------------------
   Sample product data
   (Use simple filenames like "s1.jpg" or full URLs; filenames will be resolved to assets/)
   --------------------------- */
const PRODUCTS = [
  { id: 's1', title: 'Silk Tailored Shorts', category: 'Shorts', price: 429, img: 'Trim Minimalist Women White Outfit.jpeg', desc: 'Smooth silk blend tailored shorts — elevated summer staple.' },
  { id: 's2', title: 'Pleated Mini Skirt', category: 'Skirts', price: 499, img: 'Mid Rise Faux Pearl Button Mini Skirt.jpeg', desc: 'Fine pleats, elegant silhouette.' },
  { id: 't1', title: 'Cashmere Blend Top', category: 'Tops', price: 799, img: 'Nixi Twist Leather Top Handle Bag.jpeg', desc: 'Lightweight cashmere for refined comfort.' },
  { id: 'p1', title: 'High Waist Trousers', category: 'Pants', price: 899, img: 'Pants1.jpeg', desc: 'Tailored high waist with subtle taper.' },
  { id: 'a1', title: 'Leather Belt — Matte', category: 'Accessories', price: 249, img: 'LeatherBelt.jpeg', desc: 'Minimal matte leather belt.' },
  { id: 'a2', title: 'Glasses', category: 'Accessories', price: 399, img: 'Glasses.jpeg', desc: 'Classic gold hoops.' },
  // ...add more accessories as needed...
  { id: 's3', title: 'Linen A-line Skirt', category: 'Skirts', price: 359, img: 'Flap Front Golden Button Trim Skorts in Ivory beige.jpeg', desc: 'Breezy linen in a soft A-line cut.' },
  { id: 'p2', title: 'Wide-Leg Culottes', category: 'Pants', price: 579, img: 'Pants3.jpeg', desc: 'Versatile culottes that dress up or down.' },
  { id: 'p3', title: 'Tailored Satin Trousers', category: 'Pants', price: 649, img: 'Pants2.jpeg', desc: 'Satin finish, streamlined silhouette.' },
];
// normalize categories (Bottoms -> Pants) for consistent UI
PRODUCTS.forEach(p => { if (p.category === 'Bottoms') p.category = 'Pants'; });

const PLACEHOLDER_IMG = 'heroimage.png';

/* Simplified image path helper
   - If given a full URL, absolute path, return as-is.
   - Otherwise treat value as a filename and return it directly (images are in root).
*/
function simpleImagePath(src){
  if(!src) return PLACEHOLDER_IMG;
  const s = String(src).trim();
  if(/^https?:\/\//i.test(s) || s.startsWith('/')) return s;
  return s;
}

/* ---------------------------
   Cart helpers
   --------------------------- */
const CART_KEY = 'Break Of Dawn_cart_v1';

function readCart(){
  try{
    const raw = localStorage.getItem(CART_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch(e){
    console.error('Failed to read cart', e);
    return [];
  }
}
function saveCart(cart){
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateNavCounts();
}
function addToCart(productId, qty = 1){
  const cart = readCart();
  const existing = cart.find(i=>i.id === productId);
  if(existing){
    existing.qty = Math.max(1, existing.qty + 1); // always add only 1 per click
  } else {
    const p = PRODUCTS.find(x=>x.id===productId);
    if(!p) return;
    cart.push({ id: p.id, title: p.title, price: p.price, img: p.img, qty: 1 });
  }
  saveCart(cart);
  showToast('Added to cart');
}
function removeFromCart(productId){
  let cart = readCart();
  cart = cart.filter(i=>i.id !== productId);
  saveCart(cart);
}
function updateQty(productId, qty){
  const cart = readCart();
  const it = cart.find(i=>i.id === productId);
  if(!it) return;
  it.qty = Math.max(1, Number(qty) || 1);
  saveCart(cart);
}
function clearCart(){
  saveCart([]);
}
function cartTotal(){
  const cart = readCart();
  return cart.reduce((s,i)=> s + i.price * i.qty, 0);
}
function cartCount(){
  const cart = readCart();
  return cart.reduce((s,i)=> s + i.qty, 0);
}

/* ---------------------------
   UI helpers
   --------------------------- */
function updateNavCounts(){
  const cnt = cartCount();
  // multiple nav count elements across pages have different IDs
  ['nav-cart-count','nav-cart-count-shop','nav-cart-count-product','nav-cart-count-cart','nav-cart-count-about','nav-cart-count-contact']
    .forEach(id=>{
      const el = document.getElementById(id);
      if(el) el.textContent = cnt;
    });
}

/* Simple toast (small ephemeral message) */
function showToast(msg){
  const el = document.createElement('div');
  el.textContent = msg;
  el.style.position = 'fixed';
  el.style.right = '18px';
  el.style.bottom = '18px';
  el.style.padding = '10px 14px';
  el.style.background = 'rgba(17,17,17,0.9)';
  el.style.color = '#fff';
  el.style.borderRadius = '8px';
  el.style.boxShadow = '0 8px 22px rgba(10,10,10,0.2)';
  el.style.zIndex = 9999;
  document.body.appendChild(el);
  setTimeout(()=> el.style.opacity = '0', 1500);
  setTimeout(()=> el.remove(), 2100);
}

/* ---------------------------
   Render helpers for pages
   --------------------------- */
function makeProductCard(p){
  const wrap = document.createElement('article');
  wrap.className = 'product';
  const imgSrc = simpleImagePath(p.img);
  wrap.innerHTML = `
    <div class="product-img">
      <span class="img-bg" aria-hidden="true" style="background-image:url('${imgSrc.replace(/'/g,"\\'")}')"></span>
      <img class="prod-img" src="${imgSrc}" alt="${escapeHTML(p.title)}" loading="lazy"
           onerror="this.onerror=null;console.warn('Image load failed:', this.src);this.src='${PLACEHOLDER_IMG}';" />
    </div>
    <div class="p-body">
      <div class="title">${escapeHTML(p.title)}</div>
      <div class="price">R${p.price}</div>
      <div style="margin-top:auto;display:flex;gap:10px">
        <a class="btn btn-outline" href="product.html?id=${encodeURIComponent(p.id)}">View</a>
        <button class="btn btn-primary add-btn" data-id="${p.id}">Add to cart</button>
      </div>
    </div>
  `;
  return wrap;
}

/* Render featured on index page */
function renderFeatured(){
  const container = document.getElementById('featured-grid');
  if(!container) return;
  const featured = PRODUCTS.slice(0,3);
  container.innerHTML = '';
  featured.forEach(p=>{
    container.appendChild(makeProductCard(p));
  });
  // attach listeners
  document.querySelectorAll('.add-btn').forEach(b=>{
    b.addEventListener('click', (e)=> {
      const id = e.currentTarget.dataset.id;
      addToCart(id,1);
    });
  });
}

// normalize category helper (case-insensitive, trims whitespace)
function normalizeCat(s){ return String(s || '').trim().toLowerCase(); }

function renderProducts(category){
  const container = document.getElementById('products-grid');
  if(!container) return;
  const normFilter = category ? normalizeCat(category) : null;

  // filter using normalized categories (robust to casing/whitespace)
  const items = normFilter
    ? PRODUCTS.filter(p => normalizeCat(p.category) === normFilter)
    : PRODUCTS;

  container.innerHTML = '';
  if(items.length === 0){
    container.innerHTML = '<div class="muted">No items found.</div>';
    return;
  }
  items.forEach(p=>{
    container.appendChild(makeProductCard(p));
  });
  document.querySelectorAll('.add-btn').forEach(b=>{
    b.addEventListener('click', (e)=> {
      const id = e.currentTarget.dataset.id;
      addToCart(id,1);
    });
  });
}

/* Render single product page based on ?id= */
function renderProductDetail(){
  const area = document.getElementById('product-area');
  if(!area) return;
  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  if(!id){
    area.innerHTML = '<div class="muted">No product specified.</div>';
    return;
  }
  const product = PRODUCTS.find(p=>p.id === id);
  if(!product){
    area.innerHTML = '<div class="muted">Product not found.</div>';
    return;
  }
  const imgSrc = simpleImagePath(product.img);
  area.innerHTML = `
    <div class="product-area">
      <div class="product-img" style="max-width:560px;margin-right:28px">
        <span class="img-bg" aria-hidden="true" style="background-image:url('${imgSrc.replace(/'/g,"\\'")}')"></span>
        <img src="${imgSrc}" alt="${escapeHTML(product.title)}"
             onerror="this.onerror=null;console.warn('Image load failed:', this.src);this.src='${PLACEHOLDER_IMG}';" />
      </div>
      <div>
        <h1 style="font-family: 'Times New Roman', Georgia, serif;">${escapeHTML(product.title)}</h1>
        <div class="price" style="color:var(--accent);font-weight:700;margin-top:6px">R${product.price}</div>
        <p class="muted" style="margin-top:12px">${escapeHTML(product.desc)}</p>
        <div style="margin-top:18px;display:flex;gap:12px">
          <button class="btn btn-primary" id="buy-now">Buy now</button>
          <button class="btn btn-outline" id="add-cart">Add to cart</button>
        </div>
      </div>
    </div>
  `;
  document.getElementById('add-cart').addEventListener('click', ()=> addToCart(product.id,1));
  document.getElementById('buy-now').addEventListener('click', ()=>{
    addToCart(product.id,1);
    location.href = 'cart.html';
  });
}

/* Render cart page */
function renderCartPage(){
  const area = document.getElementById('cart-area');
  const sidebar = document.getElementById('cart-sidebar');
  if(!area || !sidebar) return;
  const cart = readCart();
  if(cart.length === 0){
    area.innerHTML = `<div class="muted">Your cart is empty. <a href="shop.html">Shop now</a></div>`;
    sidebar.innerHTML = '';
    return;
  }
  area.innerHTML = '';
  cart.forEach(item=>{
    const row = document.createElement('div');
    row.className = 'cart-row';
    const imgSrc = simpleImagePath(item.img);
    row.innerHTML = `
      <div class="cart-thumb" style="width:84px;margin-right:12px">
        <span class="img-bg" aria-hidden="true" style="background-image:url('${imgSrc.replace(/'/g,"\\'")}')"></span>
        <img src="${imgSrc}" alt="${escapeHTML(item.title)}"
             onerror="this.onerror=null;console.warn('Image load failed:', this.src);this.src='${PLACEHOLDER_IMG}';" />
      </div>
      <div style="flex:1">
        <div style="font-weight:600">${escapeHTML(item.title)}</div>
        <div class="muted">R${item.price}</div>
      </div>
      <div style="display:flex;gap:8px;align-items:center">
        <input class="qty-input" type="number" min="1" value="${item.qty}" data-id="${item.id}" />
        <button class="btn btn-outline remove-btn" data-id="${item.id}">Remove</button>
      </div>
    `;
    area.appendChild(row);
  });

  // sidebar summary
  sidebar.innerHTML = `
    <div class="card">
      <div style="font-weight:700">Order summary</div>
      <div style="margin-top:12px">Items: ${cart.reduce((s,i)=> s + i.qty,0)}</div>
      <div style="margin-top:6px;font-weight:700">Subtotal: R${cartTotal()}</div>
      <div style="margin-top:14px;display:flex;gap:10px">
        <button id="checkout-btn" class="btn btn-primary">Checkout</button>
        <button id="clear-cart" class="btn btn-outline">Clear</button>
      </div>
    </div>
  `;

  // listeners
  document.querySelectorAll('.qty-input').forEach(inp=>{
    inp.addEventListener('change', (e)=>{
      const id = e.target.dataset.id;
      const val = Math.max(1, Number(e.target.value) || 1);
      updateQty(id, val);
      renderCartPage(); // re-render
    });
  });
  document.querySelectorAll('.remove-btn').forEach(b=>{
    b.addEventListener('click', (e)=>{
      removeFromCart(e.currentTarget.dataset.id);
      renderCartPage();
    });
  });
  document.getElementById('clear-cart').addEventListener('click', ()=> {
    clearCart();
    renderCartPage();
  });
  document.getElementById('checkout-btn').addEventListener('click', ()=> {
    alert('Checkout demo — integrate a payment provider for real orders.');
  });
}

/* ---------------------------
   Utilities & init
   --------------------------- */
function escapeHTML(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

/* Newsletter (simple front-end demo) */
(function attachNewsletter(){
  const f = document.getElementById('newsletter-form');
  if(!f) return;
  f.addEventListener('submit', (e)=>{
    e.preventDefault();
    const email = document.getElementById('newsletter-email').value;
    if(!email) return showToast('Please enter an email');
    showToast('Thanks — you\'re subscribed (demo)');
    f.reset();
  });
})();

/* Contact form handler */
function submitContact(evt){
  evt.preventDefault();
  const name = document.getElementById('contact-name').value.trim();
  const email = document.getElementById('contact-email').value.trim();
  const msg = document.getElementById('contact-message').value.trim();
  if(!name || !email || !msg) return showToast('Please complete the form');
  showToast('Message sent (demo). We will contact you soon.');
  document.getElementById('contact-form').reset();
}

/* Initialize common elements on all pages */
function initCommon(){
  // set copyright years
  for(let i=1;i<=6;i++){
    const el = document.getElementById('year' + (i===1? ''+i : i));
    // old HTML used year, year2... but to avoid missing we also set multiple ids
  }
  // simpler: set all elements that are span with id starting year
  document.querySelectorAll('[id^=year]').forEach(e=>{
    e.textContent = new Date().getFullYear();
  });

  updateNavCounts();
  // attach add listeners for dynamically rendered pages via event delegation where needed
  document.addEventListener('click', function(ev){
    const t = ev.target;
    if(t.matches && t.matches('.add-btn')){
      addToCart(t.dataset.id,1);
    }
  });
}

/* Entry point: detect which page and run appropriate renderers */
document.addEventListener('DOMContentLoaded', ()=>{
  initCommon();
  renderFeatured();
  updateNavCounts();

  // index.html -> render featured already
  if(document.getElementById('products-grid')){
    // shop page
    renderProducts();
  }
  if(document.getElementById('product-area')){
    renderProductDetail();
  }
  if(document.getElementById('cart-area')){
    renderCartPage();
  }
});
